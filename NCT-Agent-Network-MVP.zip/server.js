const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "network.json");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({
      agents: [],
      messages: [],
      sessions: []
    }, null, 2));
  }
}
ensureDb();

function readDb() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function writeDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function id(prefix) {
  return prefix + "_" + crypto.randomBytes(8).toString("hex");
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, original] = stored.split(":");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(original, "hex"));
}

function cleanAgent(agent) {
  return {
    id: agent.id,
    name: agent.name,
    phone: agent.phone || "",
    island: agent.island || "",
    locality: agent.locality || "",
    role: agent.role || "Agent",
    status: agent.status || "active",
    createdAt: agent.createdAt
  };
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ success: false, message: "Authentification requise." });

  const db = readDb();
  const session = db.sessions.find(s => s.token === token);
  if (!session) return res.status(401).json({ success: false, message: "Session invalide ou expirée." });

  const agent = db.agents.find(a => a.id === session.agentId);
  if (!agent) return res.status(401).json({ success: false, message: "Agent introuvable." });

  req.agent = agent;
  req.token = token;
  next();
}

// Accueil
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Vérification du serveur
app.get("/api/status", (req, res) => {
  const db = readDb();
  res.json({
    success: true,
    message: "NCT Agent Network fonctionne correctement.",
    agents: db.agents.length,
    online: db.agents.filter(a => a.status === "active").length
  });
});

// Inscription d'un agent
app.post("/api/register", (req, res) => {
  const { name, phone, password, island, locality, role } = req.body;

  if (!name || !password) {
    return res.status(400).json({
      success: false,
      message: "Nom et mot de passe obligatoires."
    });
  }

  if (password.length < 6) {
    return res.status(400).json({
      success: false,
      message: "Le mot de passe doit contenir au moins 6 caractères."
    });
  }

  const db = readDb();

  if (phone && db.agents.some(a => a.phone === phone)) {
    return res.status(409).json({
      success: false,
      message: "Ce numéro est déjà enregistré."
    });
  }

  const agent = {
    id: id("agent"),
    name: name.trim(),
    phone: phone ? phone.trim() : "",
    password: hashPassword(password),
    island: island || "",
    locality: locality || "",
    role: role || "Agent",
    status: "active",
    createdAt: new Date().toISOString()
  };

  db.agents.push(agent);
  writeDb(db);

  res.status(201).json({
    success: true,
    message: "Agent enregistré avec succès.",
    agent: cleanAgent(agent)
  });
});

// Connexion
app.post("/api/login", (req, res) => {
  const { phone, password } = req.body;
  const db = readDb();

  const agent = db.agents.find(a => a.phone === phone);
  if (!agent || !verifyPassword(password || "", agent.password)) {
    return res.status(401).json({
      success: false,
      message: "Numéro ou mot de passe incorrect."
    });
  }

  const token = id("session");
  db.sessions = db.sessions.filter(s => s.agentId !== agent.id);
  db.sessions.push({
    token,
    agentId: agent.id,
    createdAt: new Date().toISOString()
  });
  agent.status = "active";
  writeDb(db);

  res.json({
    success: true,
    message: "Connexion réussie.",
    token,
    agent: cleanAgent(agent)
  });
});

// Profil
app.get("/api/me", auth, (req, res) => {
  res.json({ success: true, agent: cleanAgent(req.agent) });
});

// Déconnexion
app.post("/api/logout", auth, (req, res) => {
  const db = readDb();
  db.sessions = db.sessions.filter(s => s.token !== req.token);
  const agent = db.agents.find(a => a.id === req.agent.id);
  if (agent) agent.status = "offline";
  writeDb(db);
  res.json({ success: true, message: "Déconnexion réussie." });
});

// Annuaire du réseau
app.get("/api/agents", auth, (req, res) => {
  const db = readDb();
  const agents = db.agents
    .filter(a => a.id !== req.agent.id)
    .map(cleanAgent)
    .sort((a, b) => a.name.localeCompare(b.name));

  res.json({ success: true, agents });
});

// Ajouter un agent par un membre connecté
app.post("/api/agents", auth, (req, res) => {
  const { name, phone, island, locality, role } = req.body;

  if (!name) {
    return res.status(400).json({ success: false, message: "Le nom est obligatoire." });
  }

  const db = readDb();
  if (phone && db.agents.some(a => a.phone === phone)) {
    return res.status(409).json({ success: false, message: "Numéro déjà enregistré." });
  }

  const temporaryPassword = crypto.randomBytes(6).toString("base64url");
  const agent = {
    id: id("agent"),
    name: name.trim(),
    phone: phone || "",
    password: hashPassword(temporaryPassword),
    island: island || "",
    locality: locality || "",
    role: role || "Agent",
    status: "active",
    createdAt: new Date().toISOString()
  };

  db.agents.push(agent);
  writeDb(db);

  res.status(201).json({
    success: true,
    message: "Agent ajouté au réseau.",
    agent: cleanAgent(agent),
    temporaryPassword
  });
});

// Messages internes
app.get("/api/messages", auth, (req, res) => {
  const db = readDb();
  const messages = db.messages
    .filter(m => m.to === "all" || m.to === req.agent.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({ success: true, messages });
});

app.post("/api/messages", auth, (req, res) => {
  const { text, to = "all" } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ success: false, message: "Message vide." });
  }

  const db = readDb();
  const message = {
    id: id("msg"),
    from: req.agent.id,
    fromName: req.agent.name,
    to,
    text: text.trim(),
    createdAt: new Date().toISOString()
  };

  db.messages.push(message);
  writeDb(db);

  res.status(201).json({ success: true, message });
});

app.get("/api/network", auth, (req, res) => {
  const db = readDb();
  const islands = {};
  db.agents.forEach(a => {
    const island = a.island || "Non renseignée";
    islands[island] = (islands[island] || 0) + 1;
  });

  res.json({
    success: true,
    totalAgents: db.agents.length,
    activeAgents: db.agents.filter(a => a.status === "active").length,
    islands
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`NCT Agent Network lancé sur le port ${PORT}`);
});