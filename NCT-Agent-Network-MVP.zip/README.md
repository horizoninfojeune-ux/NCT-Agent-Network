# NCT-Agent-Network

Plateforme web de gestion, d'inscription et de collaboration des agents.

## Fonctionnalités MVP

- Inscription des agents
- Connexion sécurisée avec mot de passe haché
- Sessions par token
- Profil agent
- Annuaire des agents
- Ajout d'agents
- Statistiques du réseau
- Messages internes
- Interface responsive pour téléphone
- API REST Express

## Installation

```bash
npm install
npm start
```

Puis ouvrir :

http://localhost:3000

## Déploiement

Le serveur écoute sur `0.0.0.0` et utilise `process.env.PORT`, ce qui permet un déploiement sur une plateforme Node.js.

## Important pour la production

Le stockage actuel utilise `data/network.json`. Il est adapté à un prototype/MVP. Pour un vrai réseau public avec plusieurs agents, il faudra remplacer ce stockage par une base de données persistante (PostgreSQL, MySQL, etc.), ajouter une gestion des rôles et renforcer la sécurité.
